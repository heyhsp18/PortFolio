let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');
let sections = document.querySelectorAll('section');
let navlinks = document.querySelectorAll('header nav a');

menuIcon.addEventListener('click', () => {
    navbar.classList.toggle('active');
});

window.addEventListener('scroll', () => {
    let fromTop = window.scrollY;
    
    sections.forEach(section => {
        let sectionId = section.getAttribute('id');
        let navLink = document.querySelector(`header nav a[href="#${sectionId}"]`);

        if (navLink) {
            let sectionOffset = section.offsetTop;
            let sectionHeight = section.offsetHeight;

            if (fromTop >= sectionOffset && fromTop < sectionOffset + sectionHeight) {
                navLink.classList.add('active');
            } else {
                navLink.classList.remove('active');
            }
        }
    });
});
